
-- --------------------------------------------------------

--
-- Table structure for table `status`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `status`;
CREATE TABLE IF NOT EXISTS `status` (
  `status_id` int NOT NULL AUTO_INCREMENT,
  `status_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `descr` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `date_created` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `status`
--

INSERT DELAYED INTO `status` (`status_id`, `status_name`, `descr`, `date_created`) VALUES
(1, 'Active', 'Patients who have not defaulted for over five consecutive days', '2024-03-05 20:09:41'),
(3, 'LTFU', 'Patients who have defaulted for over 30 consecutive days', '2024-03-05 20:11:35'),
(4, 'Defaulted', 'Patients who have missed doses for five consecutive days', '2024-03-05 20:12:08'),
(5, 'Stopped', 'Patient who have been stopped by healthcare worker', '2024-03-05 20:13:03'),
(6, 'Transit', 'Patients who have come to pick drugs for a short period or a day following temporary relocation', '2024-03-05 20:14:01'),
(7, 'Transout', 'Patients who have relocated to other place and include prisoners', '2024-03-05 20:15:26'),
(8, 'Dead', 'Patients who succumbed for whichever reason', '2024-03-05 20:24:25'),
(9, 'Weaned', 'Patients who have had a successful replacement therapy and are no longer in need of nay replacement therapy and neither are they abusing drugs again', '2024-03-05 20:28:24'),
(10, 'Transit-End', 'Clients on transit who have ended', '2024-01-03 00:00:00'),
(11, 'Voluntary Discontinuation', 'Voluntary Discontinuation', '2025-09-30 23:04:01');
