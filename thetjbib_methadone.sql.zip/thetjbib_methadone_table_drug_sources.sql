
-- --------------------------------------------------------

--
-- Table structure for table `drug_sources`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `drug_sources`;
CREATE TABLE IF NOT EXISTS `drug_sources` (
  `source_id` int NOT NULL AUTO_INCREMENT,
  `source_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `date_created` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`source_id`),
  UNIQUE KEY `source_name` (`source_name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `drug_sources`
--

INSERT DELAYED INTO `drug_sources` (`source_id`, `source_name`, `date_created`) VALUES
(1, 'KEMSA', '2024-03-08 15:57:41'),
(2, 'MEDS', '2024-03-08 15:58:45'),
(5, 'Malindi MAT Clinic', '2024-03-08 16:26:21');
