
-- --------------------------------------------------------

--
-- Table structure for table `medical_history`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `medical_history`;
CREATE TABLE IF NOT EXISTS `medical_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `visitDate` datetime DEFAULT CURRENT_TIMESTAMP,
  `mat_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `clientName` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `nickName` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `sname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `dob` date NOT NULL,
  `reg_date` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `sex` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `hiv_status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `marital_status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `art_regimen` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `regimen_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `tb_status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `tb_regimen` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `tb_start_date` date DEFAULT NULL,
  `tb_end_date` date DEFAULT NULL,
  `tpt_regimen` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `tpt_start_date` date DEFAULT NULL,
  `tpt_end_date` date DEFAULT NULL,
  `hepc_status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `other_status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `clinical_notes` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `current_status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `last_vlDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `results` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `clinician_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `next_appointment` date DEFAULT NULL,
  `rx_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `appointment_status` enum('scheduled','done') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'scheduled',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `medical_history`
--

INSERT DELAYED INTO `medical_history` (`id`, `visitDate`, `mat_id`, `clientName`, `nickName`, `sname`, `dob`, `reg_date`, `sex`, `hiv_status`, `marital_status`, `art_regimen`, `regimen_type`, `tb_status`, `tb_regimen`, `tb_start_date`, `tb_end_date`, `tpt_regimen`, `tpt_start_date`, `tpt_end_date`, `hepc_status`, `other_status`, `clinical_notes`, `current_status`, `last_vlDate`, `results`, `clinician_name`, `next_appointment`, `rx_date`, `appointment_status`) VALUES
(1, '2025-10-23 00:00:00', '454545', 'egesa', 'eges', 'egesa', '1998-02-17', '2025-10-22 00:00:00', 'Male', 'Negative', 'Married (Polygamous)', 'Not Provided', 'Not Provided', 'Unknown', '', NULL, NULL, '', NULL, NULL, 'Unknown', 'None', '', 'Active', NULL, '', 'User Admin', '2025-10-25', '2025-10-23 09:03:06', NULL),
(2, '2025-10-23 00:00:00', '197836MAT0001', 'Lyani Sitti', '', '', '1957-06-06', '2025-10-22 00:00:00', 'Male', 'Negative', '', 'Not Provided', 'Not Provided', 'Unknown', '', NULL, NULL, '', NULL, NULL, 'Unknown', 'None', '', 'Active', NULL, '', 'User Admin', '2025-10-25', '2025-10-23 09:05:07', NULL),
(3, '2025-10-23 00:00:00', '290980003', 'JOHN MWANGI', 'OMWANAWEFE', 'OMWAMI', '1990-10-10', '2025-02-10 00:00:00', 'Male', 'Positive', 'Cohabiting', 'AF2E - TDF + 3TC + DTG', 'First Line', 'Positive', '', NULL, NULL, '', NULL, NULL, 'Unknown', 'Hypertension', 'VIRALLY SUPPRESED', 'Active', '2025-04-23', 'LDL', 'Bakata Ali', '2025-02-11', '2025-10-23 14:12:43', NULL),
(4, '2025-10-23 00:00:00', '28293MAT011', 'DJ CATNIP', '', '', '2000-01-01', '2025-10-23 00:00:00', 'Female', 'Negative', '', 'Not Provided', 'Not Provided', 'Negative', '', NULL, NULL, '', NULL, NULL, 'Positive', 'None', '', 'Active', NULL, '', 'User Admin', '2025-10-31', '2025-10-23 14:12:55', NULL),
(5, '2025-10-23 00:00:00', '968745', 'John Cena', '', '', '1965-07-08', '2025-08-14 00:00:00', 'Female', 'Positive', 'Cohabiting', 'AF2E - TDF + 3TC + DTG', 'None', 'Unknown', '', NULL, NULL, '', NULL, NULL, 'Unknown', 'None', '', 'Active', NULL, '', 'User Admin', '2025-11-28', '2025-10-23 14:12:56', NULL),
(6, '2025-10-23 00:00:00', 'k1029', 'justin', 'jay', 'musyoka', '2018-03-01', '2025-10-22 00:00:00', 'Male', 'Positive', 'Single', 'AF2E - TDF + 3TC + DTG', 'First Line', 'Negative', '', NULL, NULL, '', NULL, NULL, 'Negative', 'Diabetes', '', 'Active', '2025-01-23', '', 'User Admin', '2025-11-23', '2025-10-23 14:13:30', NULL),
(7, '2025-10-23 00:00:00', '454545', 'egesa', 'eges', 'egesa', '1998-02-17', '2025-10-22 00:00:00', 'Male', 'Negative', 'Married (Polygamous)', 'Not Provided', 'Not Provided', 'Unknown', '', NULL, NULL, '', NULL, NULL, 'Unknown', 'None', '', 'Active', NULL, '', 'User Admin', '2025-10-25', '2025-10-23 14:14:21', NULL),
(8, '2025-10-23 00:00:00', '28293MAT1230', 'ANN', '', '', '1990-01-23', '2025-12-31 00:00:00', 'Female', 'Positive', '', 'None', 'None', 'Unknown', '', NULL, NULL, '', NULL, NULL, 'Unknown', 'None', '', 'Active', NULL, '', 'User Admin', '2025-11-05', '2025-10-23 14:14:29', NULL),
(9, '2025-10-23 00:00:00', '197836MAT0001', 'Lyani Sitti', '', '', '1957-06-06', '1970-01-01 00:00:00', 'Male', 'Negative', '', 'Not Provided', 'Not Provided', 'Unknown', '', NULL, NULL, '', NULL, NULL, 'Unknown', 'None', '', 'Active', NULL, '', 'User Admin', '2025-11-04', '2025-10-23 14:14:32', NULL),
(10, '2025-10-23 00:00:00', '290980003', 'JOHN MWANGI', 'OMWANAWEFE', 'OMWAMI', '1990-10-10', '2025-02-10', 'Male', 'Positive', 'Cohabiting', 'AF2E - TDF + 3TC + DTG', 'First Line', 'Positive', '2 RHZE', '2025-04-25', '2025-10-24', '', NULL, NULL, 'Negative', 'Hypertension', 'VIRALLY SUPPRESED', 'Active', '2025-04-23', 'LDL', 'Bakata Ali', '2025-02-11', '2025-10-23 14:14:34', 'scheduled'),
(11, '2025-10-23 00:00:00', '28293MAT1059', 'KIBWANA', '', 'JUMA', '2000-05-16', '2025-10-23 00:00:00', 'Male', 'Negative', '', 'Not Provided', 'Not Provided', 'Unknown', '', NULL, NULL, '', NULL, NULL, 'Positive', 'None', '', 'Active', '2025-10-23', '', 'User Admin', '2025-11-23', '2025-10-23 14:14:43', NULL),
(12, '2025-10-23 00:00:00', '28293MAT0023', 'Kassim', 'Ali', 'Kassim', '1997-10-04', '2025-10-23', 'Male', 'Negative', 'Never married', 'Not Provided', 'Not Provided', '', '', NULL, NULL, '', NULL, NULL, '', 'None', '', 'Active', NULL, 'None', 'User Admin', '2025-01-12', '2025-10-23 14:15:03', 'scheduled'),
(13, '2025-10-23 00:00:00', '23368MAT008', 'BEN', 'SULU', 'MAK', '1991-06-23', '2025-10-23 00:00:00', 'Male', 'Negative', '', 'Not Provided', 'Not Provided', 'Unknown', '', NULL, NULL, '', NULL, NULL, 'Negative', 'None', '', 'Active', NULL, '', 'User Admin', '2025-11-20', '2025-10-23 14:15:09', NULL),
(14, '2025-10-23 00:00:00', '23368MAT0001', 'JUMA', '', 'JOBWE', '1990-06-15', '2025-10-23 00:00:00', 'Male', 'Negative', '', 'Not Provided', 'Not Provided', 'Unknown', '', NULL, NULL, '', NULL, NULL, 'Unknown', 'None', '', 'Active', NULL, '', 'User Admin', '2025-10-28', '2025-10-23 15:27:28', NULL);
