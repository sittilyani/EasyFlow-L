
-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `suppliers`;
CREATE TABLE IF NOT EXISTS `suppliers` (
  `supplier_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `contact_person` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `phone` int DEFAULT NULL,
  `email` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `address` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `date_created` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`supplier_id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `suppliers`
--

INSERT DELAYED INTO `suppliers` (`supplier_id`, `name`, `contact_person`, `phone`, `email`, `address`, `date_created`) VALUES
(1, 'KEMSA', NULL, NULL, NULL, NULL, '2025-09-11 17:11:51'),
(2, 'MEDS', NULL, NULL, NULL, NULL, '2025-09-11 17:11:51'),
(3, 'Others', NULL, NULL, NULL, NULL, '2025-09-11 17:11:51');
