
-- --------------------------------------------------------

--
-- Table structure for table `offences`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `offences`;
CREATE TABLE IF NOT EXISTS `offences` (
  `offense_id` int NOT NULL AUTO_INCREMENT,
  `offense_name` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`offense_id`),
  UNIQUE KEY `offense_name` (`offense_name`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `offences`
--

INSERT DELAYED INTO `offences` (`offense_id`, `offense_name`) VALUES
(8, 'Assault'),
(6, 'Burglary/Larceny'),
(4, 'Drug peddling'),
(3, 'Drunk and disorderly'),
(12, 'Fraud/forgery'),
(10, 'Murder'),
(9, 'Rape'),
(7, 'Robbery'),
(13, 'Scrap-off'),
(11, 'Sex work'),
(1, 'Shoplifting'),
(2, 'Vandalism'),
(5, 'Weapons offense');
