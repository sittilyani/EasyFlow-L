
-- --------------------------------------------------------

--
-- Table structure for table `followup_psychiatric_form`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `followup_psychiatric_form`;
CREATE TABLE IF NOT EXISTS `followup_psychiatric_form` (
  `visit_id` int NOT NULL AUTO_INCREMENT,
  `mat_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `clientName` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `visitDate` date DEFAULT NULL,
  `progress` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `rx_pan` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `next_appointment` date DEFAULT NULL,
  `psychiatrist_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`visit_id`),
  KEY `mat_id` (`mat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
