
-- --------------------------------------------------------

--
-- Table structure for table `temp_updates`
--
-- Creation: Oct 25, 2025 at 04:17 PM
--

DROP TABLE IF EXISTS `temp_updates`;
CREATE TABLE IF NOT EXISTS `temp_updates` (
  `p_id` int NOT NULL,
  `new_clientName` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`p_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
