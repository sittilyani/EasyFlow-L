
-- --------------------------------------------------------

--
-- Table structure for table `living_conditions`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `living_conditions`;
CREATE TABLE IF NOT EXISTS `living_conditions` (
  `cond_id` int NOT NULL AUTO_INCREMENT,
  `condition_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`cond_id`),
  UNIQUE KEY `condition_name` (`condition_name`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `living_conditions`
--

INSERT DELAYED INTO `living_conditions` (`cond_id`, `condition_name`) VALUES
(3, 'Abandoned buildings'),
(6, 'Bus stations'),
(1, 'Friends House'),
(8, 'Injection Sites'),
(9, 'Other Specify'),
(5, 'Parks'),
(4, 'Public areas'),
(2, 'Streets'),
(7, 'Tunnels');
