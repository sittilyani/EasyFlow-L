
-- --------------------------------------------------------

--
-- Table structure for table `regimens`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `regimens`;
CREATE TABLE IF NOT EXISTS `regimens` (
  `regimen_id` int NOT NULL,
  `regimen_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `date_created` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`regimen_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `regimens`
--

INSERT DELAYED INTO `regimens` (`regimen_id`, `regimen_name`, `date_created`) VALUES
(1, 'AF2E - TDF + 3TC + DTG', '2024-04-14 19:29:00'),
(2, 'AF2F - TDF + 3TC + LPV/r', '2024-04-14 19:29:26'),
(3, 'AF4C - ABC + 3TC + DTG', '2024-04-14 19:29:50'),
(4, 'AF2D - TDF + 3TC + ATV/r', '2024-04-14 19:30:49'),
(5, 'AF1D - AZT + 3TC + DTG', '2024-04-14 19:31:52'),
(6, 'AF2B - TDF + 3TC + EFV', '2024-04-14 19:32:25'),
(7, 'None', '2024-04-14 19:40:14');
