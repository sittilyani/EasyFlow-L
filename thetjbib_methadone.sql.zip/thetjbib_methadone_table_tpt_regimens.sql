
-- --------------------------------------------------------

--
-- Table structure for table `tpt_regimens`
--
-- Creation: Oct 25, 2025 at 04:20 PM
--

DROP TABLE IF EXISTS `tpt_regimens`;
CREATE TABLE IF NOT EXISTS `tpt_regimens` (
  `tpt_id` int NOT NULL AUTO_INCREMENT,
  `tpt_regimen_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`tpt_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tpt_regimens`
--

INSERT DELAYED INTO `tpt_regimens` (`tpt_id`, `tpt_regimen_name`) VALUES
(1, '3H for 3 mo'),
(2, '6H for 6 mo'),
(3, '3HP once weekly for 3 mo'),
(4, 'Levofloxacin for 6 mo');
