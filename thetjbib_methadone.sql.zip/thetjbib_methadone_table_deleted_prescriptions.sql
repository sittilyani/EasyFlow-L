
-- --------------------------------------------------------

--
-- Table structure for table `deleted_prescriptions`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `deleted_prescriptions`;
CREATE TABLE IF NOT EXISTS `deleted_prescriptions` (
  `del_id` int NOT NULL AUTO_INCREMENT,
  `disp_id` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `clientName` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `mat_id` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `sex` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `drugname` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `dosage` int DEFAULT NULL,
  `pharm_officer_name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `dispDate` date DEFAULT NULL,
  `deletion_reason` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `deleted_by` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `date_of_deletion` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`del_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
