
-- --------------------------------------------------------

--
-- Table structure for table `tbl_hiv_status`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `tbl_hiv_status`;
CREATE TABLE IF NOT EXISTS `tbl_hiv_status` (
  `status_id` int NOT NULL,
  `hiv_status_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `description` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `date_created` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_hiv_status`
--

INSERT DELAYED INTO `tbl_hiv_status` (`status_id`, `hiv_status_name`, `description`, `date_created`) VALUES
(1, 'Positive', 'Patients who test positive for antibody or antigen test', '2024-04-14 19:13:05'),
(2, 'Negative', 'Patients who tested negative for serology test algorithym', '2024-04-14 19:13:50'),
(3, 'Unknown', 'Patients who have not tested for HIV serology', '2024-04-14 19:14:31'),
(1, 'Positive', 'Patients who test positive for antibody or antigen test', '2024-04-14 19:13:05'),
(2, 'Negative', 'Patients who tested negative for serology test algorithym', '2024-04-14 19:13:50'),
(3, 'Unknown', 'Patients who have not tested for HIV serology', '2024-04-14 19:14:31');
