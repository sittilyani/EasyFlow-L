
-- --------------------------------------------------------

--
-- Table structure for table `psycho_followup_visits`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `psycho_followup_visits`;
CREATE TABLE IF NOT EXISTS `psycho_followup_visits` (
  `visit_id` int NOT NULL AUTO_INCREMENT,
  `followup_name` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`visit_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `psycho_followup_visits`
--

INSERT DELAYED INTO `psycho_followup_visits` (`visit_id`, `followup_name`) VALUES
(1, 'Initial visit'),
(2, 'Followup visit 1'),
(3, 'Followup visit 2'),
(4, 'Followup visit 3'),
(5, 'Followup visit 4'),
(6, 'Followup visit 5'),
(7, 'Followup visit 6'),
(8, 'Followup visit 7'),
(9, 'Followup visit 8'),
(10, 'Followup visit 9'),
(11, 'Followup visit -other ');
