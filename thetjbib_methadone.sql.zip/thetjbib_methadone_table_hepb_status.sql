
-- --------------------------------------------------------

--
-- Table structure for table `hepb_status`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `hepb_status`;
CREATE TABLE IF NOT EXISTS `hepb_status` (
  `status_id` int NOT NULL AUTO_INCREMENT,
  `status_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `date_created` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hepb_status`
--

INSERT DELAYED INTO `hepb_status` (`status_id`, `status_name`, `date_created`) VALUES
(1, 'Positive', '2024-04-14 19:49:39'),
(2, 'Negative', '2024-04-14 19:49:44'),
(3, 'Unknown', '2024-04-14 19:49:52');
