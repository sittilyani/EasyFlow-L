
-- --------------------------------------------------------

--
-- Table structure for table `tblusers`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `tblusers`;
CREATE TABLE IF NOT EXISTS `tblusers` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `first_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `last_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `gender` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `mobile` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `photo` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `userrole` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `full_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci GENERATED ALWAYS AS (concat(`first_name`,_utf8mb4' ',`last_name`)) STORED,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=123 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblusers`
--

INSERT DELAYED INTO `tblusers` (`user_id`, `username`, `first_name`, `last_name`, `email`, `password`, `gender`, `mobile`, `photo`, `userrole`, `date_created`) VALUES
(111, 'admin', 'Matakwei', 'Mwenyewe', 'sittilyani@gmail.com', '$2y$10$dt.f.K8hdRs1y4Ymq5DrVegJIRMTIL1/REYJDfYcv8.8efhiEY7tS', 'Male', '0722427721', 'User_Admin_6_20251021.jpg', 'Admin', '2025-10-25 22:46:17'),
(112, 'hrio', 'HRIO', 'HRIO', 'hrio@gmail.com', '$2a$12$1pPO4X498FZlmq9Upgkdvutmm15WeH.61RIdxkdkQ8TSPsAsr4tq.', 'male', '0400000000', NULL, 'HRIO', '2025-10-25 22:46:17'),
(113, 'Laboratory', 'Laboratory', 'Scientist', 'lab@gmail.com', '$2y$10$dMp1FaA5Zlw7A8d//0P7I.XaScY.lxKwWCEH7DxN/z54aJRXLuaLi', 'female', '0722427721', NULL, 'Laboratory Scientist', '2025-10-25 22:46:17'),
(114, 'Guest', 'Guest', 'User', 'guest@gmail.com', '$2y$10$0/QM1eBZGjtoijcGmMhloOuqO7xUeXR0mlRK7DmN./OzAdDAQqROi', 'Female', '0444125125', 'Guest_User_36_20250924.jpeg', 'Guest', '2025-10-25 22:46:17'),
(115, 'superadmin', 'Super', 'Admin', 'superadmin@gmail.com', '$2y$10$SrytbHSMKPEEHQRvuVqHB.ZLt9F34W8TzN1zHrREyCrpxqg1iLrRO', 'Female', '0722427721', 'Super_Admin_37_20250929.jpg', 'Super Admin', '2025-10-25 22:46:17'),
(116, 'peer', 'Peer', 'Educator', 'peer@gmail.com', '$2a$12$uIXQbeEexXv/XjfZSRqDneRpqt13PqItzDki.IrRnsx8mQFtDqFHe', 'Male', '0123456789', '', 'Peer Educator', '2025-10-25 22:46:17'),
(117, 'psychologist', 'Psychologist', 'User', 'psychologist@gmail.com', '$2a$12$uIXQbeEexXv/XjfZSRqDneRpqt13PqItzDki.IrRnsx8mQFtDqFHe', 'Male', '0123456788', '', 'Psychologist', '2025-10-25 22:46:17'),
(118, 'psychiatrist', 'Pyschiatrist', 'User', 'psychiatrist@gmail.com', '$2a$12$uIXQbeEexXv/XjfZSRqDneRpqt13PqItzDki.IrRnsx8mQFtDqFHe', 'Male', '0123456787', '', 'Psychiatrist', '2025-10-25 22:46:17'),
(119, 'data', 'Data', 'Manager', 'data@gmail.com', '$2y$10$wN/p.4AvLt1G6h1l.VCka.EddYi5Aif2ppF88CQaQQ0FWIAmib6yG', 'Male', '0123456786', '', 'Data Manager', '2025-10-25 22:46:17'),
(120, 'receptionist', 'Receptionist', 'User', 'receptionist@gmail.com', '$2a$12$uIXQbeEexXv/XjfZSRqDneRpqt13PqItzDki.IrRnsx8mQFtDqFHe', 'Male', '0123456785', '', 'Receptionist', '2025-10-25 22:46:17'),
(121, 'pharmacist', 'Pharmacist', 'User', 'pharmacist@gmail.com', '$2a$12$uIXQbeEexXv/XjfZSRqDneRpqt13PqItzDki.IrRnsx8mQFtDqFHe', 'Male', '0123456784', 'Pharmacist_User_43_20251007.jpg', 'Pharmacist', '2025-10-25 22:46:17'),
(122, 'guest2', 'Guest', 'Two', 'guest2@gmail.com', '$2y$10$bXOxhmhwXBQNtU.TYoxFReOTsTBJjuOV8TSnefGvV7iGz94LnABlO', 'Female', '0999999999', '', 'Guest', '2025-10-25 22:46:17');

--
-- Triggers `tblusers`
--
DROP TRIGGER IF EXISTS `trg_populate_full_name`;
DELIMITER $$
CREATE TRIGGER `trg_populate_full_name` BEFORE INSERT ON `tblusers` FOR EACH ROW BEGIN
    SET NEW.full_name = CONCAT(NEW.first_name, ' ', NEW.last_name);
END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `trg_populate_full_name_insert`;
DELIMITER $$
CREATE TRIGGER `trg_populate_full_name_insert` BEFORE INSERT ON `tblusers` FOR EACH ROW BEGIN
    SET NEW.full_name = CONCAT(NEW.first_name, ' ', NEW.last_name);
END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `trg_populate_full_name_update`;
DELIMITER $$
CREATE TRIGGER `trg_populate_full_name_update` BEFORE UPDATE ON `tblusers` FOR EACH ROW BEGIN
    SET NEW.full_name = CONCAT(NEW.first_name, ' ', NEW.last_name);
END
$$
DELIMITER ;
