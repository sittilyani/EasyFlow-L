
-- --------------------------------------------------------

--
-- Table structure for table `administrationroutes`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `administrationroutes`;
CREATE TABLE IF NOT EXISTS `administrationroutes` (
  `route_id` int NOT NULL AUTO_INCREMENT,
  `routetype` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `date_created` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`route_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `administrationroutes`
--

INSERT DELAYED INTO `administrationroutes` (`route_id`, `routetype`, `date_created`) VALUES
(1, 'Oral', '2025-05-28 00:00:00'),
(2, 'Intramuscular', '2025-05-28 00:00:00'),
(3, 'Intravenous', '2025-05-28 00:00:00'),
(4, 'Sub Cutaneous', '2025-05-28 00:00:00'),
(5, 'Rectal', '2025-05-28 00:00:00'),
(6, 'Vaginal', '2025-05-28 00:00:00'),
(7, 'Inhalation', '2025-05-28 00:00:00');
