
-- --------------------------------------------------------

--
-- Table structure for table `education_level`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `education_level`;
CREATE TABLE IF NOT EXISTS `education_level` (
  `edu_id` int NOT NULL AUTO_INCREMENT,
  `edu_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`edu_id`),
  UNIQUE KEY `edu_name` (`edu_name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `education_level`
--

INSERT DELAYED INTO `education_level` (`edu_id`, `edu_name`) VALUES
(5, 'None'),
(4, 'Other'),
(3, 'Post-secondary'),
(1, 'Primary'),
(2, 'Secondary');
