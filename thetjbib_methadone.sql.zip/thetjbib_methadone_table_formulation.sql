
-- --------------------------------------------------------

--
-- Table structure for table `formulation`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `formulation`;
CREATE TABLE IF NOT EXISTS `formulation` (
  `formID` int NOT NULL AUTO_INCREMENT,
  `fname` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`formID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `formulation`
--

INSERT DELAYED INTO `formulation` (`formID`, `fname`, `description`) VALUES
(1, 'Oral Solution', 'Taken Orally'),
(2, 'Tablets', 'To be Swallowed with water'),
(3, 'powder', 'Mix with clean water'),
(4, 'injections', 'Inject as per the mfg instructions'),
(5, 'Eye/Eye drops', 'To be used in eyes and ears');
