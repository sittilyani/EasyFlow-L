
-- --------------------------------------------------------

--
-- Table structure for table `tblreferral`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `tblreferral`;
CREATE TABLE IF NOT EXISTS `tblreferral` (
  `referralID` int NOT NULL,
  `referralType` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `date_created` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblreferral`
--

INSERT DELAYED INTO `tblreferral` (`referralID`, `referralType`, `date_created`) VALUES
(1, 'Self', '2024-04-09 18:59:40'),
(2, 'GoK facility', '2024-04-09 18:59:53'),
(3, 'Private Facility', '2024-04-09 19:00:12'),
(4, 'CSO', '2024-04-09 19:00:17'),
(5, 'Transfer from MAT clinic', '2024-04-09 19:00:31'),
(6, 'Criminal Justice Sytem', '2024-04-09 19:00:43'),
(7, 'Other referral', '2024-04-09 19:00:59');
