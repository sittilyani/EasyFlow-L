
-- --------------------------------------------------------

--
-- Table structure for table `csos`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `csos`;
CREATE TABLE IF NOT EXISTS `csos` (
  `cso_id` int NOT NULL AUTO_INCREMENT,
  `cso_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`cso_id`),
  UNIQUE KEY `cso_name` (`cso_name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `csos`
--

INSERT DELAYED INTO `csos` (`cso_id`, `cso_name`) VALUES
(1, 'LVCT'),
(2, 'MEWA'),
(3, 'Reach Out'),
(4, 'Teens Watch'),
(5, 'The Omari Project');
