
--
-- Constraints for dumped tables
--

--
-- Constraints for table `facility_settings`
--
ALTER TABLE `facility_settings`
  ADD CONSTRAINT `facility_settings_ibfk_1` FOREIGN KEY (`facility_id`) REFERENCES `facilities` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `fingerprints`
--
ALTER TABLE `fingerprints`
  ADD CONSTRAINT `fingerprints_ibfk_1` FOREIGN KEY (`mat_id`) REFERENCES `patients` (`mat_id`);

--
-- Constraints for table `followup_psychiatric_form`
--
ALTER TABLE `followup_psychiatric_form`
  ADD CONSTRAINT `followup_psychiatric_form_ibfk_1` FOREIGN KEY (`mat_id`) REFERENCES `patients` (`mat_id`);

--
-- Constraints for table `initial_psychiatric_form`
--
ALTER TABLE `initial_psychiatric_form`
  ADD CONSTRAINT `initial_psychiatric_form_ibfk_1` FOREIGN KEY (`mat_id`) REFERENCES `patients` (`mat_id`);

--
-- Constraints for table `laboratory`
--
ALTER TABLE `laboratory`
  ADD CONSTRAINT `fk_mat_id` FOREIGN KEY (`mat_id`) REFERENCES `patients` (`mat_id`) ON DELETE CASCADE;

--
-- Constraints for table `photos`
--
ALTER TABLE `photos`
  ADD CONSTRAINT `photos_ibfk_1` FOREIGN KEY (`mat_id`) REFERENCES `patients` (`mat_id`);

--
-- Constraints for table `prescription_drugs`
--
ALTER TABLE `prescription_drugs`
  ADD CONSTRAINT `prescription_drugs_ibfk_1` FOREIGN KEY (`prescription_id`) REFERENCES `other_prescriptions` (`prescription_id`);
