
-- --------------------------------------------------------

--
-- Table structure for table `counties`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `counties`;
CREATE TABLE IF NOT EXISTS `counties` (
  `id` int NOT NULL AUTO_INCREMENT,
  `county_code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `county_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `region` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `date_created` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `county_code` (`county_code`),
  UNIQUE KEY `county_name` (`county_name`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `counties`
--

INSERT DELAYED INTO `counties` (`id`, `county_code`, `county_name`, `region`, `date_created`) VALUES
(1, '001', 'Mombasa (County)', 'Coast', '2025-01-10 00:00:00'),
(2, '002', 'Kwale', 'Coast', '2025-01-10 00:00:00'),
(3, '003', 'Kilifi', 'Coast', '2025-01-10 00:00:00'),
(4, '004', 'Tana River', 'Coast', '2025-01-10 00:00:00'),
(5, '005', 'Lamu', 'Coast', '2025-01-10 00:00:00'),
(6, '006', 'Taita Taveta', 'Coast', '2025-01-10 00:00:00'),
(7, '007', 'Garissa', 'North Eastern', '2025-01-10 00:00:00'),
(8, '008', 'Wajir', 'North Eastern', '2025-01-10 00:00:00'),
(9, '009', 'Mandera', 'North Eastern', '2025-01-10 00:00:00'),
(10, '010', 'Marsabit', 'North Eastern', '2025-01-10 00:00:00'),
(11, '011', 'Isiolo', 'North Eastern', '2025-01-10 00:00:00'),
(12, '012', 'Meru', 'Eastern', '2025-01-10 00:00:00'),
(13, '013', 'Tharaka-Nithi', 'Eastern', '2025-01-10 00:00:00'),
(14, '014', 'Embu', 'Eastern', '2025-01-10 00:00:00'),
(15, '015', 'Kitui', 'Eastern', '2025-01-10 00:00:00'),
(16, '016', 'Machakos', 'Eastern', '2025-01-10 00:00:00'),
(17, '017', 'Makueni', 'Eastern', '2025-01-10 00:00:00'),
(18, '018', 'Nyandarua', 'Central', '2025-01-10 00:00:00'),
(19, '019', 'Nyeri', 'Central', '2025-01-10 00:00:00'),
(20, '020', 'Kirinyaga', 'Central', '2025-01-10 00:00:00'),
(21, '021', 'Murang\'a', 'Central', '2025-01-10 00:00:00'),
(22, '022', 'Kiambu', 'Central', '2025-01-10 00:00:00'),
(23, '023', 'Turkana', 'Rift Valley', '2025-01-10 00:00:00'),
(24, '024', 'West Pokot', 'Rift Valley', '2025-01-10 00:00:00'),
(25, '025', 'Samburu', 'Rift Valley', '2025-01-10 00:00:00'),
(26, '026', 'Trans-Nzoia', 'Rift Valley', '2025-01-10 00:00:00'),
(27, '027', 'Uasin Gishu', 'Rift Valley', '2025-01-10 00:00:00'),
(28, '028', 'Elgeyo-Marakwet', 'Rift Valley', '2025-01-10 00:00:00'),
(29, '029', 'Nandi', 'Rift Valley', '2025-01-10 00:00:00'),
(30, '030', 'Baringo', 'Rift Valley', '2025-01-10 00:00:00'),
(31, '031', 'Laikipia', 'Rift Valley', '2025-01-10 00:00:00'),
(32, '032', 'Nakuru', 'Rift Valley', '2025-01-10 00:00:00'),
(33, '033', 'Narok', 'Rift Valley', '2025-01-10 00:00:00'),
(34, '034', 'Kajiado', 'Rift Valley', '2025-01-10 00:00:00'),
(35, '035', 'Kericho', 'Rift Valley', '2025-01-10 00:00:00'),
(36, '036', 'Bomet', 'Rift Valley', '2025-01-10 00:00:00'),
(37, '037', 'Kakamega', 'Western', '2025-01-10 00:00:00'),
(38, '038', 'Vihiga', 'Western', '2025-01-10 00:00:00'),
(39, '039', 'Bungoma', 'Western', '2025-01-10 00:00:00'),
(40, '040', 'Busia', 'Western', '2025-01-10 00:00:00'),
(41, '041', 'Siaya', 'Nyanza', '2025-01-10 00:00:00'),
(42, '042', 'Kisumu', 'Nyanza', '2025-01-10 00:00:00'),
(43, '043', 'Homa Bay', 'Nyanza', '2025-01-10 00:00:00'),
(44, '044', 'Migori', 'Nyanza', '2025-01-10 00:00:00'),
(45, '045', 'Kisii', 'Nyanza', '2025-01-10 00:00:00'),
(46, '046', 'Nyamira', 'Nyanza', '2025-01-10 00:00:00'),
(47, '047', 'Nairobi (County)', 'Nairobi (City)', '2025-01-10 00:00:00'),
(48, '048', 'LVCT Health County', 'LVCT Health Region', '2025-10-10 19:37:01');
