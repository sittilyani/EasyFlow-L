
-- --------------------------------------------------------

--
-- Table structure for table `stocks`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `stocks`;
CREATE TABLE IF NOT EXISTS `stocks` (
  `stockID` int NOT NULL AUTO_INCREMENT,
  `drugID` int NOT NULL,
  `transactionType` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `productname` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `brandname` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `reorderLevel` int DEFAULT NULL,
  `openingBalance` double DEFAULT '0',
  `quantityIn` int DEFAULT NULL,
  `batch` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `receivedFrom` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `quantityOut` int DEFAULT '0',
  `transDate` datetime DEFAULT CURRENT_TIMESTAMP,
  `stockBalance` int DEFAULT NULL,
  `status` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `transBy` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`stockID`),
  KEY `idx_stocks_brandname_transDate` (`brandname`,`transDate` DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
