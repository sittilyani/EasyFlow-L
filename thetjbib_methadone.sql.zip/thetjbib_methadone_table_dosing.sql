
-- --------------------------------------------------------

--
-- Table structure for table `dosing`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `dosing`;
CREATE TABLE IF NOT EXISTS `dosing` (
  `id` int NOT NULL AUTO_INCREMENT,
  `dosage` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dosing`
--

INSERT DELAYED INTO `dosing` (`id`, `dosage`) VALUES
(1, 'OD'),
(2, 'BD'),
(3, 'TID'),
(4, 'TDS'),
(5, 'QID'),
(6, 'PRN');
