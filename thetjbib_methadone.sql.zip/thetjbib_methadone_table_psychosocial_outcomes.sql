
-- --------------------------------------------------------

--
-- Table structure for table `psychosocial_outcomes`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `psychosocial_outcomes`;
CREATE TABLE IF NOT EXISTS `psychosocial_outcomes` (
  `psyc_outcome_id` int NOT NULL AUTO_INCREMENT,
  `outcome_name` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`psyc_outcome_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `psychosocial_outcomes`
--

INSERT DELAYED INTO `psychosocial_outcomes` (`psyc_outcome_id`, `outcome_name`) VALUES
(1, 'Reintegration'),
(2, 'Stable accomodation'),
(3, 'GBV'),
(4, 'Employment'),
(5, 'Legal problems'),
(6, 'Other outcomes');
