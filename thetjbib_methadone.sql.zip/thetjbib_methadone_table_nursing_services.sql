
-- --------------------------------------------------------

--
-- Table structure for table `nursing_services`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `nursing_services`;
CREATE TABLE IF NOT EXISTS `nursing_services` (
  `nursing_id` int NOT NULL AUTO_INCREMENT,
  `nurising_service_name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`nursing_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `nursing_services`
--

INSERT DELAYED INTO `nursing_services` (`nursing_id`, `nurising_service_name`) VALUES
(1, 'Wound dressing'),
(2, 'Injection');
