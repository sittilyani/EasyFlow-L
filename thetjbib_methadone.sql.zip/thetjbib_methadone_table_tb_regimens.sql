
-- --------------------------------------------------------

--
-- Table structure for table `tb_regimens`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `tb_regimens`;
CREATE TABLE IF NOT EXISTS `tb_regimens` (
  `regimen_id` int NOT NULL AUTO_INCREMENT,
  `regimen_name` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`regimen_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_regimens`
--

INSERT DELAYED INTO `tb_regimens` (`regimen_id`, `regimen_name`) VALUES
(1, '2 RHZE'),
(2, '4 RH'),
(3, '10 RH'),
(4, '4 Km/Mfx/Pto/Cfz/H-Inh/Z/E'),
(5, '5 Mfx/Cfz//Z/E'),
(6, '15 R/Z/Lfx');
