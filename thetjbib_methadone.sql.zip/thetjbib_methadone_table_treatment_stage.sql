
-- --------------------------------------------------------

--
-- Table structure for table `treatment_stage`
--
-- Creation: Oct 25, 2025 at 04:20 PM
--

DROP TABLE IF EXISTS `treatment_stage`;
CREATE TABLE IF NOT EXISTS `treatment_stage` (
  `stage_id` int NOT NULL AUTO_INCREMENT,
  `stage_of_rx_name` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`stage_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `treatment_stage`
--

INSERT DELAYED INTO `treatment_stage` (`stage_id`, `stage_of_rx_name`) VALUES
(1, 'Induction'),
(2, 'Reinduction'),
(3, 'Stabilization'),
(4, 'Maintenance'),
(5, 'Cessation'),
(6, 'Other');
