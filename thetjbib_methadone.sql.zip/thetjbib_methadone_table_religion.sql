
-- --------------------------------------------------------

--
-- Table structure for table `religion`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `religion`;
CREATE TABLE IF NOT EXISTS `religion` (
  `id` int NOT NULL AUTO_INCREMENT,
  `religion_name` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `religion`
--

INSERT DELAYED INTO `religion` (`id`, `religion_name`) VALUES
(1, 'Islam'),
(2, 'Christian'),
(3, 'Hindu'),
(4, 'Buddhist'),
(5, 'Atheist'),
(6, 'Other');
