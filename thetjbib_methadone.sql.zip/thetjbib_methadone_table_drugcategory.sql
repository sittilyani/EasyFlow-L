
-- --------------------------------------------------------

--
-- Table structure for table `drugcategory`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `drugcategory`;
CREATE TABLE IF NOT EXISTS `drugcategory` (
  `id` int NOT NULL AUTO_INCREMENT,
  `catname` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `description` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `drugcategory`
--

INSERT DELAYED INTO `drugcategory` (`id`, `catname`, `description`) VALUES
(1, 'antihistamine', 'Relieves inflammatory symptoms'),
(2, 'narcotic', 'Used where analgesic drugs have low pain threshold'),
(3, 'stimulant', 'Stimulates the brain and can be used to relieve depressive symptoms'),
(4, 'analgesic', 'This is are non-steroidal anti-inflammatory drugs classes'),
(5, 'antibacterial', 'Any naturally-derived drugs for management of bacterial infections'),
(6, 'antiviral', 'Kills or inactivates or stops viral replication'),
(7, 'steroids', 'This are corticosteroids and other steroids used in inflammatory management'),
(9, 'Antidote', 'Antidote for Methadone poisoning or overdose'),
(10, 'Antipsychotic', 'Suppress the brain neural system and calms the patient'),
(12, 'medicines', 'other prescritions');
