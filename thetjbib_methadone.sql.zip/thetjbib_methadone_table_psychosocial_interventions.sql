
-- --------------------------------------------------------

--
-- Table structure for table `psychosocial_interventions`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `psychosocial_interventions`;
CREATE TABLE IF NOT EXISTS `psychosocial_interventions` (
  `intervention_id` int NOT NULL AUTO_INCREMENT,
  `intervention_name` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`intervention_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `psychosocial_interventions`
--

INSERT DELAYED INTO `psychosocial_interventions` (`intervention_id`, `intervention_name`) VALUES
(1, 'Individual Therapy'),
(2, 'Couple Therapy'),
(3, 'Group Therapy'),
(4, 'Family Therapy'),
(5, 'Psycho Education'),
(6, 'Crisis/Conflict Management'),
(7, 'None');
