
-- --------------------------------------------------------

--
-- Table structure for table `referral_linkage_services`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `referral_linkage_services`;
CREATE TABLE IF NOT EXISTS `referral_linkage_services` (
  `ref_id` int NOT NULL AUTO_INCREMENT,
  `ref_name` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`ref_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `referral_linkage_services`
--

INSERT DELAYED INTO `referral_linkage_services` (`ref_id`, `ref_name`) VALUES
(1, 'Education Programs'),
(2, 'Legal Support'),
(3, 'Community Networks Support'),
(4, 'Peer Support Networks'),
(5, 'Family Support Services'),
(6, 'Rehabilitation'),
(7, 'Mental Health'),
(8, 'Medical services'),
(9, 'HIV services'),
(10, 'GBV Services'),
(11, 'None'),
(12, 'Primary'),
(13, 'Secondary'),
(14, 'Post-secondary'),
(15, 'Others'),
(16, 'None');
