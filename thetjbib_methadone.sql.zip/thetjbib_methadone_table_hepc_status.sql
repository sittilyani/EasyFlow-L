
-- --------------------------------------------------------

--
-- Table structure for table `hepc_status`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `hepc_status`;
CREATE TABLE IF NOT EXISTS `hepc_status` (
  `status_id` int NOT NULL AUTO_INCREMENT,
  `status_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `date_created` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hepc_status`
--

INSERT DELAYED INTO `hepc_status` (`status_id`, `status_name`, `date_created`) VALUES
(1, 'Positive', '2024-04-14 19:47:23'),
(2, 'Negative', '2024-04-14 19:47:29'),
(3, 'Unknown', '2024-04-14 19:47:37');
