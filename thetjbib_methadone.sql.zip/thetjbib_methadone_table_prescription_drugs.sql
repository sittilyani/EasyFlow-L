
-- --------------------------------------------------------

--
-- Table structure for table `prescription_drugs`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `prescription_drugs`;
CREATE TABLE IF NOT EXISTS `prescription_drugs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `prescription_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `drug_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `dosing` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `frequency` int DEFAULT NULL,
  `days` int DEFAULT NULL,
  `total_dosage` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `total_dispensed` int NOT NULL DEFAULT '0',
  `remaining_balance` int DEFAULT '0',
  `prescr_status` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'pending',
  PRIMARY KEY (`id`),
  KEY `prescription_id` (`prescription_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `prescription_drugs`
--

INSERT DELAYED INTO `prescription_drugs` (`id`, `prescription_id`, `drug_name`, `dosing`, `frequency`, `days`, `total_dosage`, `total_dispensed`, `remaining_balance`, `prescr_status`) VALUES
(1, 'PRESCR-00000001', 'Amitriptyline 25mg', '1', 1, 12, '12', 12, -12, 'dispensed and closed'),
(2, 'PRESCR-00000002', 'Ambroxol Hydrochloride 15mg/5mL', '2', 2, 2, '8', 8, -8, 'dispensed and closed'),
(3, 'PRESCR-00000002', 'Albendazole 400mg/10mL', '1', 1, 1, '1', 1, -1, 'dispensed and closed'),
(4, 'PRESCR-00000003', 'Methadone', '30', 1, 33030370, '990911100', 0, 0, 'pending'),
(5, 'PRESCR-00000004', 'Methadone', '30', 1, 7, '210', 0, 0, 'pending'),
(6, 'PRESCR-00000004', 'Amoxicillin 500mg', '500', 15, 5, '37500', 0, 0, 'pending'),
(7, 'PRESCR-00000005', 'Methadone', '30', 1, 1, '30', 0, 30, '0'),
(8, 'PRESCR-00000005', 'Albendazole 400mg/10mL', '400', 1, 1, '400', 0, 400, '0'),
(9, 'PRESCR-00000005', 'Amlodipine 5mg', '5', 1, 10, '50', 0, 50, '0'),
(10, 'PRESCR-00000006', 'Methadone', '30', 1, 5, '150', 0, 0, 'pending'),
(11, 'PRESCR-00000006', 'Albendazole 400mg', '1', 1, 1, '1', 0, 0, 'pending'),
(12, 'PRESCR-00000006', 'Amlodipine 5mg', '5', 2, 10, '100', 0, 0, 'pending'),
(13, 'PRESCR-00000007', 'Amitriptyline 25mg', '2', 1, 5, '10', 10, -10, 'dispensed and closed'),
(14, 'PRESCR-00000008', 'Albendazole 400mg', '1', 1, 1, '1', 1, -1, 'dispensed and closed'),
(15, 'PRESCR-00000009', 'Amoxicillin 500mg', '1', 3, 5, '15', 15, -15, 'dispensed and closed'),
(16, 'PRESCR-00000010', 'Albendazole 400mg/10mL', '400', 1, 1, '400', 0, 0, 'pending'),
(17, 'PRESCR-00000011', 'Albendazole 400mg', '1', 1, 1, '1', 0, 0, 'pending'),
(18, 'PRESCR-00000012', 'Methadone', '30', 1, 77, '2310', 0, 0, 'pending'),
(19, 'PRESCR-00000013', 'Methadone', '2', 12, 28, '672', 0, 0, 'pending'),
(20, 'PRESCR-00000014', 'Albendazole 400mg', '1', 1, 1, '1', 0, 0, 'pending'),
(21, 'PRESCR-00000015', 'Albendazole 400mg', '1', 1, 1, '1', 0, 0, 'pending'),
(22, 'PRESCR-00000016', 'Albendazole 400mg', '1', 1, 1, '', 0, 0, 'pending');
