
-- --------------------------------------------------------

--
-- Table structure for table `employment_status`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `employment_status`;
CREATE TABLE IF NOT EXISTS `employment_status` (
  `emp_id` int NOT NULL AUTO_INCREMENT,
  `emp_status_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`emp_id`),
  UNIQUE KEY `emp_status_name` (`emp_status_name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employment_status`
--

INSERT DELAYED INTO `employment_status` (`emp_id`, `emp_status_name`) VALUES
(3, 'Self employment'),
(1, 'Skilled employment'),
(4, 'Unemployed'),
(2, 'Unskilled employment');
