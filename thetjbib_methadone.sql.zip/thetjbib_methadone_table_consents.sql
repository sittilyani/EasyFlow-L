
-- --------------------------------------------------------

--
-- Table structure for table `consents`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `consents`;
CREATE TABLE IF NOT EXISTS `consents` (
  `consent_id` int NOT NULL AUTO_INCREMENT,
  `clientName` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `mat_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `hcw_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `date_of_consent` datetime DEFAULT CURRENT_TIMESTAMP,
  `visitDate` datetime DEFAULT CURRENT_TIMESTAMP,
  `consent_status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`consent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
