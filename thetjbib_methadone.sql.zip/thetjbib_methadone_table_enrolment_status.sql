
-- --------------------------------------------------------

--
-- Table structure for table `enrolment_status`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `enrolment_status`;
CREATE TABLE IF NOT EXISTS `enrolment_status` (
  `enrolment_id` int NOT NULL AUTO_INCREMENT,
  `enrolment_status_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `decsription` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `date_created` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`enrolment_id`),
  UNIQUE KEY `enrolment_status_name` (`enrolment_status_name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `enrolment_status`
--

INSERT DELAYED INTO `enrolment_status` (`enrolment_id`, `enrolment_status_name`, `decsription`, `date_created`) VALUES
(1, 'New', 'New on Methadone and never enrolled elsewhere except for a rehabilitation program if any.', '2024-04-18 11:33:16'),
(2, 'Transfer In', 'This is a client enrolled elsewhere and has been transferred in for services due to different reasons', '2024-04-18 11:33:16'),
(3, 'Re-induction', 'Defaulted or stopped and coming back', '2024-11-14 00:00:00'),
(5, 'Transit', 'On transit', '2024-01-03 00:00:00');
