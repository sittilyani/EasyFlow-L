
-- --------------------------------------------------------

--
-- Table structure for table `tblgender`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `tblgender`;
CREATE TABLE IF NOT EXISTS `tblgender` (
  `gender_id` int NOT NULL,
  `gender_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblgender`
--

INSERT DELAYED INTO `tblgender` (`gender_id`, `gender_name`) VALUES
(1, 'Female'),
(2, 'Male');
