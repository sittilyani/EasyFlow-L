
-- --------------------------------------------------------

--
-- Table structure for table `marital_status`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `marital_status`;
CREATE TABLE IF NOT EXISTS `marital_status` (
  `mar_id` int NOT NULL AUTO_INCREMENT,
  `marital_status_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `date_created` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`mar_id`),
  UNIQUE KEY `marital_status_name` (`marital_status_name`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `marital_status`
--

INSERT DELAYED INTO `marital_status` (`mar_id`, `marital_status_name`, `date_created`) VALUES
(1, 'Single', '2024-04-18 20:22:09'),
(2, 'Married (Monogamous)', '2024-04-18 20:25:09'),
(5, 'Married (Polygamous)', '2024-04-18 20:26:51'),
(6, 'Separated/Divorced', '2024-04-18 20:27:32'),
(7, 'Cohabiting', '2024-04-18 20:27:48'),
(8, 'Widowed', '2024-04-20 09:17:55'),
(9, 'Unknown', '2024-11-13 00:00:00'),
(10, 'Remarried', '2025-10-04 18:14:07'),
(11, 'Never married', '2025-10-04 18:14:07');
