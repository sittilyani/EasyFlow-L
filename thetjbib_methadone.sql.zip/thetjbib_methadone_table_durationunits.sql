
-- --------------------------------------------------------

--
-- Table structure for table `durationunits`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `durationunits`;
CREATE TABLE IF NOT EXISTS `durationunits` (
  `unit_id` int NOT NULL AUTO_INCREMENT,
  `duration` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `date_created` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`unit_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `durationunits`
--

INSERT DELAYED INTO `durationunits` (`unit_id`, `duration`, `date_created`) VALUES
(1, 'hours', '2025-05-28 00:00:00'),
(2, 'days', '2025-05-28 00:00:00'),
(3, 'weeks', '2025-05-28 00:00:00'),
(4, 'months', '2025-05-28 00:00:00');
