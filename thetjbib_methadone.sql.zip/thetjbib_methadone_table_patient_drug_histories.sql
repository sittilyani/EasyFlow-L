
-- --------------------------------------------------------

--
-- Table structure for table `patient_drug_histories`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `patient_drug_histories`;
CREATE TABLE IF NOT EXISTS `patient_drug_histories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `encounter_id` int NOT NULL,
  `drug_type` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `age_first_use` int DEFAULT NULL,
  `duration_years` int DEFAULT NULL,
  `frequency` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `quantity` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `route` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `last_used` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
