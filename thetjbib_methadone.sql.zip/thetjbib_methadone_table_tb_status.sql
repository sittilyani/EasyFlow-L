
-- --------------------------------------------------------

--
-- Table structure for table `tb_status`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `tb_status`;
CREATE TABLE IF NOT EXISTS `tb_status` (
  `status_id` int NOT NULL,
  `status_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `date_created` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_status`
--

INSERT DELAYED INTO `tb_status` (`status_id`, `status_name`, `date_created`) VALUES
(1, 'Positive', '2024-04-14 19:44:15'),
(2, 'Negative', '2024-04-14 19:44:21'),
(3, 'Unknown', '2024-04-14 19:44:30');
