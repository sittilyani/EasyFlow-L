
-- --------------------------------------------------------

--
-- Table structure for table `transaction_types`
--
-- Creation: Oct 25, 2025 at 04:20 PM
--

DROP TABLE IF EXISTS `transaction_types`;
CREATE TABLE IF NOT EXISTS `transaction_types` (
  `id` int NOT NULL,
  `transactionType` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaction_types`
--

INSERT DELAYED INTO `transaction_types` (`id`, `transactionType`) VALUES
(1, 'Purchase'),
(2, 'Promotion'),
(3, 'Donation'),
(4, 'Returns'),
(5, 'Exchange');
