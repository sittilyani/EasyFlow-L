
-- --------------------------------------------------------

--
-- Table structure for table `tblcso`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `tblcso`;
CREATE TABLE IF NOT EXISTS `tblcso` (
  `cso_id` int NOT NULL AUTO_INCREMENT,
  `cso_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `date_created` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`cso_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblcso`
--

INSERT DELAYED INTO `tblcso` (`cso_id`, `cso_name`, `description`, `date_created`) VALUES
(1, 'MEWA', 'Muslim Education and Welfare Association (MEWA) is a non â€“ profit organization, which began as a group of young Muslim professionals working in Mombasa', '2024-04-11 19:20:24'),
(2, 'RCT', 'Reachout Centre Trust is a non-profit organization founded in 24th Jan, 2003. The main mandate is to provide harm reduction services to all those in need', '2024-04-11 19:20:55'),
(3, 'ICRH-K', 'Reproductive Health, Maternal Health and Family Planning. ICRHK recognizes that reproductive health services including family planning', '2024-04-11 19:22:24'),
(4, 'Prisons Department', 'Clients enrolled through the prisons department or court', '2024-04-14 08:06:25'),
(5, 'The Omari Project (TOP)', 'The Omari Project provides preventative interventions to improve PWUD (and their families) lives within a legitimizing framework.', '2024-04-25 10:34:58'),
(6, 'Other', 'Any other CSO that is not listed.', '2024-04-25 10:34:58'),
(7, 'LVCT', 'NGO', '2025-09-30 13:10:39');
