
-- --------------------------------------------------------

--
-- Table structure for table `fingerprints`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `fingerprints`;
CREATE TABLE IF NOT EXISTS `fingerprints` (
  `print_id` int NOT NULL AUTO_INCREMENT,
  `visitDate` datetime DEFAULT CURRENT_TIMESTAMP,
  `mat_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `clientName` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sex` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `current_status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fingerprint_data` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `capture_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`print_id`),
  KEY `mat_id` (`mat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
