
-- --------------------------------------------------------

--
-- Table structure for table `facility_settings`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `facility_settings`;
CREATE TABLE IF NOT EXISTS `facility_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `facility_id` int DEFAULT NULL,
  `facilityname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `mflcode` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `countyname` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `subcountyname` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `facilityincharge` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `facilityphone` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `setup_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `facility_id` (`facility_id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `facility_settings`
--

INSERT DELAYED INTO `facility_settings` (`id`, `facility_id`, `facilityname`, `mflcode`, `countyname`, `subcountyname`, `facilityincharge`, `facilityphone`, `email`, `setup_date`) VALUES
(50, 2543, 'AAR Clinic Sarit Centre (Westlands)', NULL, 'Nairobi', 'Westlands', 'Dr. LVCT Health', '0722328739', 'lvct@lvcthealth.org', '2025-10-25 20:04:17');
