
-- --------------------------------------------------------

--
-- Table structure for table `userroles`
--
-- Creation: Oct 25, 2025 at 04:20 PM
--

DROP TABLE IF EXISTS `userroles`;
CREATE TABLE IF NOT EXISTS `userroles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `role` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `descr` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role` (`role`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `userroles`
--

INSERT DELAYED INTO `userroles` (`id`, `role`, `descr`) VALUES
(1, 'Admin', 'Overall system user'),
(2, 'Clinician', 'prescribes to patients drugs'),
(3, 'Receptionist', 'Registers patients in the system'),
(4, 'Pharmacist', 'Dispenses drugs to patients'),
(5, 'Psychologist', 'Counsels Clients'),
(6, 'Laboratory Scientist', 'Tests Clients'),
(7, 'Peer Educator', 'Check daily roll for clients'),
(8, 'HRIO', 'HRIO'),
(9, 'Psychiatrist', 'Psychiatrist'),
(10, 'Data Manager', 'Data Manager'),
(11, 'Guest', 'Guest'),
(12, 'Super Admin', 'Administrator of everything'),
(13, 'Nursing', 'Nursing services');
