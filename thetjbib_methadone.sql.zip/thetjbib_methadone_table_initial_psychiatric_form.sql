
-- --------------------------------------------------------

--
-- Table structure for table `initial_psychiatric_form`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `initial_psychiatric_form`;
CREATE TABLE IF NOT EXISTS `initial_psychiatric_form` (
  `psy_id` int NOT NULL AUTO_INCREMENT,
  `mat_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `occupation` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `visitDate` date DEFAULT NULL,
  `referral` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `rx_supporter` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `pre_complaints` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `corr_complaints` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `hx_illness` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `past_psych_hx` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `past_med_hx` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `sub_use_hx` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `fam_hx` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `ante_hx` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `dev_hx` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `child_hx` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `edu_hx` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `occup_hx` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `sex_hx` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `premord_hx` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `forens_hx` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `phys_exam` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `mental_exam` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `diagnosis` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `mgt_plan` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`psy_id`),
  KEY `mat_id` (`mat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
