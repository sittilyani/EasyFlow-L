
-- --------------------------------------------------------

--
-- Table structure for table `other_status`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `other_status`;
CREATE TABLE IF NOT EXISTS `other_status` (
  `status_id` int NOT NULL AUTO_INCREMENT,
  `status_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `date_created` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `other_status`
--

INSERT DELAYED INTO `other_status` (`status_id`, `status_name`, `date_created`) VALUES
(1, 'STI', '2024-04-14 19:52:04'),
(2, 'PrEP', '2024-04-14 19:52:12'),
(3, 'PEP', '2024-04-14 19:52:17'),
(4, 'Hypertension', '2024-04-14 19:52:34'),
(5, 'Diabetes', '2024-04-14 19:52:43'),
(6, 'Asthma', '2024-04-14 19:52:49'),
(7, 'None', '2024-04-21 00:00:00');
