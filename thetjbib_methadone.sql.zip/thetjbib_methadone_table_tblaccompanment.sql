
-- --------------------------------------------------------

--
-- Table structure for table `tblaccompanment`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `tblaccompanment`;
CREATE TABLE IF NOT EXISTS `tblaccompanment` (
  `accompanmentID` int NOT NULL,
  `accompanmentType` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `date_created` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblaccompanment`
--

INSERT DELAYED INTO `tblaccompanment` (`accompanmentID`, `accompanmentType`, `date_created`) VALUES
(1, 'Parent', '2024-04-09 19:18:26'),
(2, 'Partner', '2024-04-09 19:18:37'),
(3, 'Friend', '2024-04-09 19:18:47'),
(4, 'Outreach worker', '2024-04-09 19:19:02'),
(5, 'Other', '2024-04-09 19:19:14'),
(6, 'None', '2024-04-13 17:56:29'),
(7, 'Prison Warden', '2024-04-14 08:24:37'),
(1, 'Parent', '2024-04-09 19:18:26'),
(2, 'Partner', '2024-04-09 19:18:37'),
(3, 'Friend', '2024-04-09 19:18:47'),
(4, 'Outreach worker', '2024-04-09 19:19:02'),
(5, 'Other', '2024-04-09 19:19:14'),
(6, 'None', '2024-04-13 17:56:29'),
(7, 'Prison Warden', '2024-04-14 08:24:37');
