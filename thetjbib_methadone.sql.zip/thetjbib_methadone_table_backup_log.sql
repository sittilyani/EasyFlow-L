
-- --------------------------------------------------------

--
-- Table structure for table `backup_log`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `backup_log`;
CREATE TABLE IF NOT EXISTS `backup_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `backup_date` date NOT NULL,
  `backup_type` enum('morning','midday') COLLATE utf8mb4_general_ci NOT NULL,
  `backup_file` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
