
-- --------------------------------------------------------

--
-- Table structure for table `psychiatric_rx_problems`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `psychiatric_rx_problems`;
CREATE TABLE IF NOT EXISTS `psychiatric_rx_problems` (
  `problem_id` int NOT NULL AUTO_INCREMENT,
  `problem_name` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`problem_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `psychiatric_rx_problems`
--

INSERT DELAYED INTO `psychiatric_rx_problems` (`problem_id`, `problem_name`) VALUES
(1, 'Drug use'),
(2, 'Psychological'),
(3, 'Health'),
(4, 'Legal problem'),
(5, 'Physical health'),
(6, 'Social functioning');
