
-- --------------------------------------------------------

--
-- Table structure for table `integration_status`
--
-- Creation: Oct 25, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `integration_status`;
CREATE TABLE IF NOT EXISTS `integration_status` (
  `integration_id` int NOT NULL AUTO_INCREMENT,
  `integration_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`integration_id`),
  UNIQUE KEY `integration_name` (`integration_name`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `integration_status`
--

INSERT DELAYED INTO `integration_status` (`integration_id`, `integration_name`) VALUES
(6, 'Community Reintegration'),
(10, 'Cultural Reintegration'),
(5, 'Education Reintegration'),
(2, 'Employment Reintegration'),
(1, 'Family Reintegration'),
(8, 'Health Reintegration'),
(3, 'Housing Reintegration'),
(7, 'Legal Reintegration'),
(11, 'None'),
(9, 'Peer Support Reintegration'),
(4, 'Stable Reintegration');
